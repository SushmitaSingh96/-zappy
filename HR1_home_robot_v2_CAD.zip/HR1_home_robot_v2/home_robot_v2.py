"""
HR-1 Home Robot — v2 parametric CAD model (CadQuery)
=====================================================
Units: mm. Z up, +X = front.

v2 layout
  * Base and upper shell: both Ø420, so closed the robot is one clean cylinder.
  * Telescopic column: 4 nested tubes (1 fixed + 3 moving), 800 mm stroke, offset 50 mm
    to the rear. Closed, every tube is hidden inside the two shells.
    Overall height 650 mm (closed) -> 1450 mm (fully raised).
  * 5-DOF arm folds flat inside the upper shell; a curved sliding door covers the opening.
  * Camera: smoked dome flush in the top, with pan (360°) + tilt inside.

Run:  python home_robot_v2.py   -> out_v2/ (STEP closed / ready / raised, STLs, viewer JSON)
"""
import json, os, math
import cadquery as cq

OUT = "out_v2"

P = dict(
    D=420, R=210, wall=3,
    base_z0=18, base_top=350,                 # base shell z range
    upper_h=255,                               # upper shell height (seam to top surface)
    wheel_d=150, wheel_w=40, wheel_y=165,
    chassis_z0=26, chassis_t=8,
    col_x=-50, col_d=(100, 88, 76, 64), col_wall=3, col_len=520, stroke=800,
    j1=(40, -120), j1_z=30,                    # J1 axis position, top of J1 actuator (upper frame)
    sh_h=48,                                   # shoulder axis above J1 output
    L1=230, L2=205, off=-55,                   # link lengths, forearm lateral offset
    win=(-88, 55), door_open=146,              # door window angles (deg), door travel
)
CAMERA_TOP = P["upper_h"] + 45                 # dome top, upper frame

POSES = {
    "closed": dict(ext=0, door=0, q1=90, q2=0, q3=180, q4=-90, q5=0, grip=10, pan=0, tilt=0),
    "ready":  dict(ext=300, door=1, q1=0, q2=20, q3=-70, q4=50, q5=0, grip=50, pan=0, tilt=-15),
    "floor":  dict(ext=0, door=1, q1=0, q2=-15, q3=-70, q4=-5, q5=0, grip=60, pan=0, tilt=-40),
    "raised": dict(ext=800, door=1, q1=0, q2=30, q3=-20, q4=-10, q5=90, grip=60, pan=0, tilt=0),
}

# Collision-checked unfold sequence (closed -> ready); reverse it to stow.
DEPLOY_PATH = [
    dict(door=1),                    # 1. door slides open
    dict(q1=0),                      # 2. folded arm swings out through the opening
    dict(q4=-150),                   # 3. gripper tips outward
    dict(q2=-8),                     # 4. shoulder dips 8° to clear the top edge
    dict(q3=90),                     # 5. elbow unfolds upward
    dict(q2=20, q3=-70, q4=50, grip=50, tilt=-15),   # 6. into ready pose
    dict(ext=300),                   # 7. column rises to working height
]

C = dict(
    sand=(0.85, 0.80, 0.70), sand_dk=(0.76, 0.70, 0.60), wgrey=(0.52, 0.50, 0.47),
    dark=(0.23, 0.22, 0.21), rubber=(0.11, 0.11, 0.11), alu=(0.74, 0.72, 0.69),
    smoke=(0.10, 0.10, 0.11), light=(1.00, 0.86, 0.66), pcb=(0.25, 0.33, 0.27),
)

# ------------------------------------------------------------------ helpers
def cyl_z(d, h, z0=0, x=0, y=0):
    return cq.Workplane("XY").workplane(offset=z0).center(x, y).circle(d / 2).extrude(h)

def cyl_y(d, length, x=0, z=0, yc=0):
    return (cq.Workplane("XZ").center(x, z).circle(d / 2)
            .extrude(length / 2, both=True).translate((0, yc, 0)))

def cyl_x(d, length, x0=0, y=0, z=0):
    return cq.Workplane("YZ").workplane(offset=x0).center(y, z).circle(d / 2).extrude(length)

def box(x0, x1, y0, y1, z0, z1):
    return (cq.Workplane("XY").box(x1 - x0, y1 - y0, z1 - z0)
            .translate(((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2)))

def tube_z(od, wall, z0, h, x=0, y=0):
    return cyl_z(od, h, z0, x, y).cut(cyl_z(od - 2 * wall, h + 2, z0 - 1, x, y))

def wedge(a0, a1, r, z0, z1, n=24):
    pts = [(0, 0)] + [(r * math.cos(math.radians(a0 + (a1 - a0) * k / n)),
                       r * math.sin(math.radians(a0 + (a1 - a0) * k / n))) for k in range(n + 1)]
    return cq.Workplane("XY").workplane(offset=z0).polyline(pts).close().extrude(z1 - z0)

def safe_fillet(wp, sel, r):
    try:
        return wp.edges(sel).fillet(r)
    except Exception:
        return wp

PARTS = {}
def part(name, frame, wp, color, note):
    PARTS[name] = (frame, wp, color, note)

R, D, w = P["R"], P["D"], P["wall"]
cx = P["col_x"]

# ================================================================== BASE (frame base)
zb0, zbt = P["base_z0"], P["base_top"]
outer = cyl_z(D, zbt - zb0, zb0).faces(">Z").edges().fillet(4).faces("<Z").edges().fillet(8)
inner = cyl_z(D - 2 * w, zbt - zb0 - w + 1, zb0 - 1)
base_shell = outer.cut(inner).cut(cyl_z(108, 20, zbt - 10, cx, 0))
WIN = [box(-86, 86, 148, 240, 0, 168), box(-86, 86, -240, -148, 0, 168)]
for b in WIN:
    base_shell = base_shell.cut(b)
part("base_shell", "base", base_shell, C["sand"],
     "Vacuum-formed ABS/ASA 3 mm (or rotomolded PE), one piece, sand beige")

bumper = cyl_z(D + 8, 28, 22).cut(cyl_z(D - 2, 30, 21))
for b in WIN:
    bumper = bumper.cut(b)
part("base_bumper", "base", bumper, C["wgrey"], "Extruded TPE bumper strip, warm grey")

chassis = cyl_z(D - 20, P["chassis_t"], P["chassis_z0"])
for b in (box(-84, 84, 150, 240, 0, 60), box(-84, 84, -240, -150, 0, 60)):
    chassis = chassis.cut(b)
part("base_chassis_plate", "base", chassis, C["alu"],
     "8 mm 5083 aluminium plate, laser/waterjet cut — structural spine")

wz = P["wheel_d"] / 2
for s, tag in ((1, "L"), (-1, "R")):
    yc = s * P["wheel_y"]
    tire = safe_fillet(cyl_y(P["wheel_d"], P["wheel_w"], 0, wz, yc), None, 9)
    tire = tire.cut(cyl_y(100, P["wheel_w"] + 2, 0, wz, yc))
    part(f"wheel_tire_{tag}", "base", tire, C["rubber"], "Cast PU tread, 85A")
    part(f"wheel_hub_{tag}", "base", cyl_y(100, P["wheel_w"] - 4, 0, wz, yc), C["wgrey"],
         "Moulded or turned hub")
    part(f"drive_motor_{tag}", "base", cyl_y(60, 60, 0, wz, s * 112), C["dark"],
         "24 V BLDC planetary gearmotor, ~60 mm")
    br = box(-40, 40, s * 140 - 3, s * 140 + 3, P["chassis_z0"] + 8, 115).cut(cyl_y(22, 20, 0, wz, s * 140))
    part(f"motor_bracket_{tag}", "base", br, C["alu"], "6 mm aluminium, laser cut")

for s, tag in ((1, "F"), (-1, "B")):
    x = s * 165
    part(f"caster_housing_{tag}", "base", cyl_z(56, 12, 14, x, 0), C["dark"], "Ø40 ball transfer unit")
    part(f"caster_ball_{tag}", "base", cq.Workplane("XY").sphere(20).translate((x, 0, 20)),
         C["wgrey"], "Steel ball (part of caster unit)")

z_ch = P["chassis_z0"] + P["chassis_t"]
part("battery_pack", "base", safe_fillet(box(20, 165, -70, 70, z_ch, z_ch + 120), "|Z", 6), C["dark"],
     "24 V LiFePO4 ~20 Ah, placed forward to balance the rear-offset column")
part("electronics_tray", "base", box(-185, -110, -65, 65, z_ch, z_ch + 30), C["pcb"],
     "Main compute + motor drivers")

# ================================================================== COLUMN
L = P["col_len"]
d0, d1, d2, d3 = P["col_d"]
cw = P["col_wall"]
part("column_stage0", "base", tube_z(d0, cw, z_ch, L, cx), C["alu"],
     "Ø100×3 6063 tube, fixed (hidden in base when closed)")
part("column_flange", "base", tube_z(140, 22, z_ch, 8, cx), C["alu"], "Base flange, 4× M6")
for k, d in ((1, d1), (2, d2), (3, d3)):
    part(f"column_stage{k}", f"stage{k}", tube_z(d, cw, -L, L, cx), C["alu"],
         f"Ø{d}×3 aluminium tube, POM slide bushings, 253 mm overlap at full stroke")
    part(f"column_bushing{k}", f"stage{k-1}" if k > 1 else "base",
         tube_z(d + 6, 3, (z_ch + L - 14) if k == 1 else -14, 14, cx), C["wgrey"], "POM bushing ring")
part("column_actuator", "base", cyl_z(28, 480, z_ch, cx, 0), C["dark"],
     "Internal 3-stage cable-synchronised lead-screw actuator, 24 V, 800 mm stroke")

# ================================================================== UPPER (frame upper, origin = seam)
UH = P["upper_h"]
uo = cyl_z(D, UH).faces(">Z").edges().fillet(30).faces("<Z").edges().fillet(3)
ui = cyl_z(D - 2 * w, UH - w + 1, -1).faces(">Z").edges().fillet(27)
upper = uo.cut(ui).cut(cyl_z(124, 20, UH - 10))
upper = upper.cut(wedge(P["win"][0], P["win"][1], 260, 14, 243))
part("upper_shell", "upper", upper, C["sand"],
     "Vacuum-formed ABS/ASA 3 mm, sand beige; front opening for the arm")
plate = cyl_z(D - 2 * w - 2, 6, 2).cut(cyl_z(108, 10, 0, cx, 0))
part("upper_base_plate", "upper", plate, C["alu"], "6 mm aluminium plate: arm + door track mount")
part("upper_bridge", "upper", box(cx - 20, cx + 20, -185, 185, 204, 216), C["alu"],
     "Bridge beam: column stage 3 bolts up into this")
for s, tag in ((1, "L"), (-1, "R")):
    part(f"upper_post_{tag}", "upper", box(cx - 10, cx + 10, s * 165 - 10, s * 165 + 10, 8, 204),
         C["alu"], "20×20 aluminium post, bridge to base plate")

# sliding door (frame "door", rotates about Z)
a0, a1 = P["win"][0] - 2, P["win"][1] + 2
door = cyl_z(2 * (R + 4), 235, 11).cut(cyl_z(2 * (R + 1), 240, 9)).intersect(wedge(a0, a1, 260, 0, 300))
part("arm_door", "door", door, C["sand"],
     "Curved sliding door, 3 mm ABS on top/bottom tracks, belt-driven (opens 120°)")
part("door_track", "upper", cyl_z(2 * (R + 5), 4, 7).cut(cyl_z(2 * R - 2, 6, 6)), C["wgrey"],
     "Door track ring (bottom); matching ring hidden under top fillet")

# camera dome (frame upper / cam)
part("dome_trim", "upper", tube_z(142, 12, UH - 4, 7), C["wgrey"], "Trim ring, warm grey")
part("dome_light", "upper", tube_z(152, 5, UH - 1, 2.5), C["light"], "Warm-white status light ring")
part("camera_pan_base", "cam", cyl_z(70, 14, UH - 12), C["dark"], "Pan stage, 360° continuous slip ring")
part("camera_eye", "tilt", cq.Workplane("XY").sphere(24), C["dark"], "Tilt ball housing")
part("camera_lens", "tilt", cyl_x(18, 10, 18, 0, 0).union(cyl_x(8, 3, 26, 0, 14)), C["smoke"],
     "RGB-D module (e.g. OAK-D Lite class optics)")
dome = cq.Workplane("XY").sphere(60).translate((0, 0, UH - 15)).intersect(box(-70, 70, -70, 70, UH - 2, UH + 60))
dome = dome.cut(cq.Workplane("XY").sphere(57).translate((0, 0, UH - 15)))
part("camera_dome", "upper", dome, C["smoke"], "Smoked polycarbonate dome, 3 mm")

# ================================================================== ARM
j1x, j1y = P["j1"]
part("arm_j1_actuator", "upper", cyl_z(80, P["j1_z"] - 8, 8, j1x, j1y), C["wgrey"],
     "J1 yaw: Ø80 pancake actuator, ~15 Nm")
# J1 frame: origin on J1 axis at top of actuator
part("arm_turret", "J1", cyl_z(80, 6, 0), C["dark"], "Turret output disc")
part("arm_j2_actuator", "J1", cyl_y(80, 80, 0, P["sh_h"], 0), C["wgrey"],
     "J2 shoulder: Ø80 actuator, ~40 Nm peak")
# J2 frame (shoulder axis), link along +X
part("arm_upper_link", "J2", cyl_x(42, P["L1"] - 75, 40, 0, 0), C["sand"],
     "Ø42 aluminium tube in beige cover, bonded into machined clamps")
part("arm_j3_actuator", "J2", cyl_y(66, 100, P["L1"], 0, P["off"] / 2), C["wgrey"],
     "J3 elbow: Ø66 actuator, ~20 Nm, spans both link planes")
# J3 frame (elbow axis); forearm in plane y = off
part("arm_fore_link", "J3", cyl_x(36, P["L2"] - 60, 33, P["off"], 0), C["sand"], "Ø36 tube in beige cover")
part("arm_j4_actuator", "J3", cyl_y(50, 56, P["L2"], 0, P["off"]), C["wgrey"],
     "J4 wrist pitch: Ø50 servo actuator (Dynamixel XM540 class)")
# J4 frame (wrist pitch axis at (L2, off, 0) in J3)
part("arm_j5_actuator", "J4", cyl_x(50, 40, 20, 0, 0), C["wgrey"], "J5 wrist roll: Ø50 servo actuator")
# J5 frame at (60,0,0) in J4
part("gripper_body", "J5", safe_fillet(box(0, 40, -36, 36, -20, 20), "|X", 6), C["sand"],
     "PA12 printed housing, rack-and-pinion parallel gripper")
for s, tag in ((1, "L"), (-1, "R")):
    f = safe_fillet(box(40, 95, 0, 9, -13, 13), ">X", 3)
    part(f"gripper_finger_{tag}", f"finger{tag}", f.translate((0, 0 if s > 0 else -9, 0)), C["dark"],
         "Printed finger, TPU pad")

# ================================================================== kinematics
def Lc(t=(0, 0, 0), axis=None, ang=0):
    return cq.Location(cq.Vector(*t)) if axis is None else cq.Location(cq.Vector(*t), cq.Vector(*axis), ang)

def frame_locs(p):
    e = p["ext"]
    F = {"base": Lc()}
    seam = P["base_top"] + e
    top0 = z_ch + L
    for k in (1, 2, 3):
        F[f"stage{k}"] = Lc((0, 0, top0 + e * k / 3))
    F["upper"] = Lc((0, 0, seam))
    F["door"] = F["upper"] * Lc(axis=(0, 0, 1), ang=p["door"] * P["door_open"])
    F["cam"] = F["upper"] * Lc(axis=(0, 0, 1), ang=p["pan"])
    F["tilt"] = F["cam"] * Lc((0, 0, UH + 8)) * Lc(axis=(0, 1, 0), ang=-p["tilt"])
    F["J1"] = F["upper"] * Lc((j1x, j1y, P["j1_z"])) * Lc(axis=(0, 0, 1), ang=p["q1"])
    F["J2"] = F["J1"] * Lc((0, 0, P["sh_h"])) * Lc(axis=(0, 1, 0), ang=-p["q2"])
    F["J3"] = F["J2"] * Lc((P["L1"], 0, 0)) * Lc(axis=(0, 1, 0), ang=-p["q3"])
    F["J4"] = F["J3"] * Lc((P["L2"], P["off"], 0)) * Lc(axis=(0, 1, 0), ang=-p["q4"])
    F["J5"] = F["J4"] * Lc((60, 0, 0)) * Lc(axis=(1, 0, 0), ang=p["q5"])
    g = p["grip"] / 2
    F["fingerL"] = F["J5"] * Lc((0, g, 0))
    F["fingerR"] = F["J5"] * Lc((0, -g, 0))
    return F

def solids(pose):
    F = frame_locs(pose)
    return {n: (wp.val() if len(wp.vals()) == 1 else cq.Compound.makeCompound(wp.vals())).moved(F[fr])
            for n, (fr, wp, c, _) in PARTS.items()}

def build_assembly(pose):
    F = frame_locs(pose)
    a = cq.Assembly(name="HR1_home_robot")
    for n, (fr, wp, col, _) in PARTS.items():
        a.add(wp, name=n, loc=F[fr], color=cq.Color(*col))
    return a

def export_all():
    os.makedirs(f"{OUT}/stl", exist_ok=True)
    for k in ("closed", "ready", "raised"):
        build_assembly(POSES[k]).export(f"{OUT}/HR1_{k}.step")
    for n, (fr, wp, col, _) in PARTS.items():
        cq.exporters.export(wp, f"{OUT}/stl/{n}.stl", tolerance=0.2, angularTolerance=0.15)
    meshes = []
    for n, (fr, wp, col, note) in PARTS.items():
        shp = wp.val() if len(wp.vals()) == 1 else cq.Compound.makeCompound(wp.vals())
        v, t = shp.tessellate(0.35, 0.25)
        meshes.append(dict(name=n, frame=fr, note=note,
                           color="#%02x%02x%02x" % tuple(int(c * 255) for c in col),
                           v=[round(c, 1) for p in v for c in (p.x, p.y, p.z)],
                           i=[k for tr in t for k in tr]))
    with open(f"{OUT}/viewer_mesh.json", "w") as fh:
        json.dump(dict(P=P, poses=POSES, deploy=DEPLOY_PATH, meshes=meshes), fh, separators=(",", ":"))

if __name__ == "__main__":
    export_all()
    print(len(PARTS), "parts ->", OUT)
